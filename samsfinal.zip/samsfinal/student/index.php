<!DOCTYPE html>
<html>
<head>
<title>Special School</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="style.css">
<!--[if IE 6]><link rel="stylesheet" type="text/css" href="css/ie6.css"><![endif]-->
</head>
<body>
<div id="header">
  <div> <a href="index.html"><img src="images/logo.gif" alt=""></a>
    <ul>
      <li class="current"><a href="../index.html">Home</a></li>
      <li><a href="../login/logout.php">Log Out</a></li>
    </ul>
  </div>
</div>
<div id="content">
  <div>
    <div>
      <h1><br> <br>Congratulations!! You are Selected in the class you have applied. <br> <br> For Further intructrion please follow our main website frequently</h1>
    
      
    </div>
  </div>
</div>
</body>
</html>
